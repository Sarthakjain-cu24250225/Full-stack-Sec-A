# QuickBite — Labsheet 11

Mini Food Delivery App for the B.Tech Full Stack Lab.

## Tech Stack
- Frontend: HTML, CSS, JavaScript (Fetch API)
- Backend: Node.js + Express
- Database: SQLite

## Features
- Menu listing, search and category filter
- Add/update/delete menu items through Admin
- Availability control
- Persistent cart using localStorage
- Checkout with client-side and server-side validation
- Server-side total calculation from current database prices
- Orders list and cancellation while status is Placed
- Admin order status progression: Placed → Preparing → Out for Delivery → Delivered
- SQLite persistence across page refresh/restart

## Folder Structure
```text
Labsheet_11_QuickBite/
├── backend/
│   ├── db.js
│   ├── server.js
│   └── package.json
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── postman/
│   └── QuickBite.postman_collection.json
├── screenshots/
└── README.md
```

## Requirements
Node.js 18+ and npm.

## Run
1. Open the `backend` folder in terminal.
2. Run:
   ```bash
   npm install
   npm start
   ```
3. Open `http://localhost:5000` in the browser.
4. The SQLite database `quickbite.db` is created automatically and sample menu items are seeded on first run.

## API List
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/items` | List menu items; supports `?search=name&category=Drinks` |
| POST | `/api/items` | Add menu item |
| PUT | `/api/items/:id` | Update menu item |
| DELETE | `/api/items/:id` | Delete menu item |
| POST | `/api/orders` | Place order |
| GET | `/api/orders` | List orders, latest first |
| PATCH | `/api/orders/:id/status` | Advance/cancel order |

## Sample POST /api/items
```json
{"name":"Margherita Pizza","price":250,"category":"Main Course","isAvailable":true}
```

## Sample POST /api/orders
```json
{"customerName":"Sarthak","phone":"9876543210","address":"Dehradun","items":[{"itemId":1,"qty":2}]}
```

## Status Rules
- Placed → Preparing → Out for Delivery → Delivered
- Cancelled is allowed only from Placed.
- A completed/cancelled order cannot move backward.

## Testing / Submission
Use the included Postman collection for at least 3 endpoint tests. Put screenshots of the working Menu, Cart, Orders and Postman results in `screenshots/` before final submission.

## GitHub Upload
From the project root:
```bash
git init
git add .
git commit -m "Complete Labsheet 11 QuickBite app"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```
Do not commit `node_modules/` or `quickbite.db` if you want a clean repository; run `npm install` after cloning.
