const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const db = new sqlite3.Database(path.join(__dirname, 'quickbite.db'));

function run(sql, params=[]) { return new Promise((resolve,reject)=>db.run(sql,params,function(err){err?reject(err):resolve({id:this.lastID,changes:this.changes});})); }
function get(sql, params=[]) { return new Promise((resolve,reject)=>db.get(sql,params,(err,row)=>err?reject(err):resolve(row))); }
function all(sql, params=[]) { return new Promise((resolve,reject)=>db.all(sql,params,(err,rows)=>err?reject(err):resolve(rows))); }

async function initDb(){
  await run(`CREATE TABLE IF NOT EXISTS menu_items(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,price REAL NOT NULL CHECK(price>0),category TEXT NOT NULL,isAvailable INTEGER NOT NULL DEFAULT 1)`);
  await run(`CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,customerName TEXT NOT NULL,phone TEXT NOT NULL,address TEXT NOT NULL,totalAmount REAL NOT NULL,status TEXT NOT NULL DEFAULT 'Placed',createdAt TEXT NOT NULL)`);
  await run(`CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,orderId INTEGER NOT NULL,itemId INTEGER NOT NULL,name TEXT NOT NULL,price REAL NOT NULL,qty INTEGER NOT NULL,FOREIGN KEY(orderId) REFERENCES orders(id))`);
  const row=await get('SELECT COUNT(*) AS count FROM menu_items');
  if(row.count===0){
    const seed=[['Veg Spring Rolls',120,'Starters',1],['Paneer Tikka',220,'Starters',1],['Butter Chicken',320,'Main Course',1],['Veg Biryani',240,'Main Course',1],['Chocolate Brownie',140,'Desserts',1],['Cold Coffee',110,'Drinks',1],['Mango Shake',130,'Drinks',1]];
    for(const x of seed) await run('INSERT INTO menu_items(name,price,category,isAvailable) VALUES(?,?,?,?)',x);
  }
}
module.exports={db,run,get,all,initDb};
