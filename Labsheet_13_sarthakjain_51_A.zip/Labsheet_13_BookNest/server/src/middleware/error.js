function notFound(req, res) {
  res.status(404).json({
    error: { code: "NOT_FOUND", message: "Route not found" }
  });
}

function errorHandler(err, req, res, next) {
  console.error(err.message);
  const status = err.status || 500;
  res.status(status).json({
    error: {
      code: err.code || "INTERNAL_ERROR",
      message: err.publicMessage || "Internal server error"
    }
  });
}

module.exports = { notFound, errorHandler };
