require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
const { createDb } = require("./db");
const authRoutes = require("./routes/auth");
const bookRoutes = require("./routes/books");
const issueRoutes = require("./routes/issues");
const { notFound, errorHandler } = require("./middleware/error");

function createApp(dbPath) {
  const app = express();
  const resolvedPath = dbPath || process.env.DB_PATH || path.join(__dirname, "../db/booknest.db");
  const db = createDb(resolvedPath);

  app.locals.db = db;

  app.use(helmet());
  app.use(cors());
  app.use(express.json());

  app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} ${req.method} ${req.originalUrl}`);
    next();
  });

  app.get("/api/health", (req, res) => res.json({ ok: true }));

  app.use("/api/auth", authRoutes(db));
  app.use("/api/books", bookRoutes(db));
  app.use("/api/issues", issueRoutes(db));

  app.use(notFound);
  app.use(errorHandler);

  return app;
}

module.exports = { createApp };
