function calculateFine(dueOn, returnedOn) {
  const due = new Date(dueOn);
  const returned = new Date(returnedOn);
  const fullDaysLate = Math.max(
    0,
    Math.floor((returned.getTime() - due.getTime()) / 86400000)
  );
  return fullDaysLate * 2;
}

function isoDatePlusDays(date, days) {
  const result = new Date(date);
  result.setDate(result.getDate() + days);
  return result.toISOString();
}

module.exports = { calculateFine, isoDatePlusDays };
