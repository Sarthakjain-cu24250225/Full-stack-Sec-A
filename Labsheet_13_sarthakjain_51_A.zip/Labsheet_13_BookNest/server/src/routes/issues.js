const express = require("express");
const { authenticate, requireRole } = require("../middleware/auth");
const { calculateFine, isoDatePlusDays } = require("../utils");

module.exports = function issueRoutes(db) {
  const router = express.Router();

  router.post("/", authenticate, requireRole("librarian"), async (req, res, next) => {
    const { member_id, book_id } = req.body || {};

    if (!Number.isInteger(member_id) || !Number.isInteger(book_id)) {
      return res.status(400).json({
        error: { code: "VALIDATION_ERROR", message: "member_id and book_id are required integers" }
      });
    }

    try {
      await db.run("BEGIN IMMEDIATE");

      const member = await db.get("SELECT id,name,email,role FROM members WHERE id = ?", [member_id]);
      if (!member) {
        await db.run("ROLLBACK");
        return res.status(404).json({
          error: { code: "MEMBER_NOT_FOUND", message: "Member not found" }
        });
      }
      if (member.role !== "member") {
        await db.run("ROLLBACK");
        return res.status(400).json({
          error: { code: "VALIDATION_ERROR", message: "Only a member can receive an issue" }
        });
      }

      const book = await db.get("SELECT * FROM books WHERE id = ?", [book_id]);
      if (!book) {
        await db.run("ROLLBACK");
        return res.status(404).json({
          error: { code: "BOOK_NOT_FOUND", message: "Book not found" }
        });
      }

      const active = await db.get(
        "SELECT COUNT(*) AS count FROM issues WHERE member_id = ? AND returned_on IS NULL",
        [member_id]
      );

      if (active.count >= 3) {
        await db.run("ROLLBACK");
        return res.status(409).json({
          error: { code: "LIMIT_REACHED", message: "Member already has 3 active issues" }
        });
      }

      const updated = await db.run(
        "UPDATE books SET available_copies = available_copies - 1 WHERE id = ? AND available_copies > 0",
        [book_id]
      );

      if (updated.changes !== 1) {
        await db.run("ROLLBACK");
        return res.status(409).json({
          error: { code: "NO_COPIES", message: "No available copies" }
        });
      }

      const issuedOn = new Date();
      const dueOn = new Date(issuedOn);
      dueOn.setDate(dueOn.getDate() + 14);

      const issue = await db.run(
        `INSERT INTO issues(member_id,book_id,issued_on,due_on,returned_on,fine)
         VALUES(?,?,?,?,NULL,0)`,
        [member_id, book_id, issuedOn.toISOString(), dueOn.toISOString()]
      );

      await db.run("COMMIT");

      const created = await db.get(
        `SELECT i.id,i.member_id,i.book_id,i.issued_on,i.due_on,i.returned_on,i.fine,
                m.name AS member_name,b.title AS book_title
         FROM issues i
         JOIN members m ON m.id=i.member_id
         JOIN books b ON b.id=i.book_id
         WHERE i.id=?`,
        [issue.lastID]
      );

      res.status(201).json(created);
    } catch (err) {
      try { await db.run("ROLLBACK"); } catch {}
      next(err);
    }
  });

  router.post("/:id/return", authenticate, requireRole("librarian"), async (req, res, next) => {
    const issueId = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(issueId)) {
      return res.status(404).json({
        error: { code: "NOT_FOUND", message: "Issue not found" }
      });
    }

    try {
      await db.run("BEGIN IMMEDIATE");

      const issue = await db.get("SELECT * FROM issues WHERE id = ?", [issueId]);
      if (!issue) {
        await db.run("ROLLBACK");
        return res.status(404).json({
          error: { code: "NOT_FOUND", message: "Issue not found" }
        });
      }

      if (issue.returned_on) {
        await db.run("ROLLBACK");
        return res.status(409).json({
          error: { code: "ALREADY_RETURNED", message: "Issue has already been returned" }
        });
      }

      const returnedOn = new Date();
      const fine = calculateFine(issue.due_on, returnedOn.toISOString());

      await db.run(
        "UPDATE issues SET returned_on = ?, fine = ? WHERE id = ? AND returned_on IS NULL",
        [returnedOn.toISOString(), fine, issueId]
      );
      await db.run(
        "UPDATE books SET available_copies = available_copies + 1 WHERE id = ?",
        [issue.book_id]
      );

      await db.run("COMMIT");
      res.json({ fine });
    } catch (err) {
      try { await db.run("ROLLBACK"); } catch {}
      next(err);
    }
  });

  router.get("/overdue", authenticate, requireRole("librarian"), async (req, res, next) => {
    try {
      const rows = await db.all(
        `SELECT i.id, m.name AS member_name, b.title AS book_title,
                CAST(julianday('now') - julianday(i.due_on) AS INTEGER) AS days_overdue,
                CAST(julianday('now') - julianday(i.due_on) AS INTEGER) * 2 AS fine
         FROM issues i
         JOIN members m ON m.id=i.member_id
         JOIN books b ON b.id=i.book_id
         WHERE i.returned_on IS NULL AND julianday('now') > julianday(i.due_on)
         ORDER BY i.id`
      );
      res.json(rows);
    } catch (err) {
      next(err);
    }
  });

  router.get("/mine", authenticate, async (req, res, next) => {
    try {
      const rows = await db.all(
        `SELECT i.id,i.book_id,b.code,b.title,b.author,i.issued_on,i.due_on,i.returned_on,i.fine
         FROM issues i
         JOIN books b ON b.id=i.book_id
         WHERE i.member_id=?
         ORDER BY i.id`,
        [req.user.id]
      );
      res.json(rows);
    } catch (err) {
      next(err);
    }
  });

  return router;
};
