const express = require("express");
const { authenticate, requireRole } = require("../middleware/auth");

module.exports = function bookRoutes(db) {
  const router = express.Router();

  router.get("/", authenticate, async (req, res, next) => {
    try {
      const search = typeof req.query.search === "string" ? req.query.search : "";
      const page = Math.max(1, Number.parseInt(req.query.page || "1", 10) || 1);
      const limit = Math.min(50, Math.max(1, Number.parseInt(req.query.limit || "10", 10) || 10));
      const offset = (page - 1) * limit;
      const pattern = `%${search}%`;

      const countRow = await db.get(
        "SELECT COUNT(*) AS total FROM books WHERE title LIKE ? COLLATE NOCASE OR author LIKE ? COLLATE NOCASE",
        [pattern, pattern]
      );

      const data = await db.all(
        `SELECT id,code,title,author,total_copies,available_copies
         FROM books
         WHERE title LIKE ? COLLATE NOCASE OR author LIKE ? COLLATE NOCASE
         ORDER BY id
         LIMIT ? OFFSET ?`,
        [pattern, pattern, limit, offset]
      );

      const total = countRow.total;
      res.json({ data, page, limit, total, totalPages: Math.ceil(total / limit) });
    } catch (err) {
      next(err);
    }
  });

  router.post("/", authenticate, requireRole("librarian"), async (req, res, next) => {
    try {
      const { code, title, author, total_copies } = req.body || {};
      if (
        typeof code !== "string" ||
        typeof title !== "string" ||
        typeof author !== "string" ||
        !Number.isInteger(total_copies) ||
        total_copies < 0 ||
        !code.trim() ||
        !title.trim() ||
        !author.trim()
      ) {
        return res.status(400).json({
          error: { code: "VALIDATION_ERROR", message: "Invalid book data" }
        });
      }

      const result = await db.run(
        `INSERT INTO books(code,title,author,total_copies,available_copies)
         VALUES(?,?,?,?,?)`,
        [code.trim(), title.trim(), author.trim(), total_copies, total_copies]
      );

      const book = await db.get("SELECT * FROM books WHERE id = ?", [result.lastID]);
      res.status(201).json(book);
    } catch (err) {
      if (String(err.message).includes("UNIQUE")) {
        return res.status(409).json({
          error: { code: "DUPLICATE_CODE", message: "Book code already exists" }
        });
      }
      next(err);
    }
  });

  return router;
};
