require("dotenv").config();
const { createApp } = require("./app");

if (!process.env.JWT_SECRET) {
  console.error("JWT_SECRET is required");
  process.exit(1);
}

const port = process.env.PORT || 3000;
const app = createApp();

app.listen(port, () => {
  console.log(`BookNest API running on http://localhost:${port}`);
});
