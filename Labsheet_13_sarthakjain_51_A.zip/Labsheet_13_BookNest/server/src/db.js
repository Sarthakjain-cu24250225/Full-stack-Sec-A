const sqlite3 = require("sqlite3").verbose();
const fs = require("fs");
const path = require("path");

function createDb(dbPath) {
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  const db = new sqlite3.Database(dbPath);

  db.run("PRAGMA foreign_keys = ON");

  return {
    db,
    run(sql, params = []) {
      return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
          if (err) reject(err);
          else resolve({ lastID: this.lastID, changes: this.changes });
        });
      });
    },
    get(sql, params = []) {
      return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => {
          if (err) reject(err);
          else resolve(row);
        });
      });
    },
    all(sql, params = []) {
      return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
      });
    },
    exec(sql) {
      return new Promise((resolve, reject) => {
        db.exec(sql, err => err ? reject(err) : resolve());
      });
    },
    close() {
      return new Promise((resolve, reject) => {
        db.close(err => err ? reject(err) : resolve());
      });
    }
  };
}

module.exports = { createDb };
