require("dotenv").config();
const fs = require("fs");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();
const bcrypt = require("bcrypt");

const dbPath = process.env.DB_PATH || path.join(__dirname, "booknest.db");
fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const schema = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
const db = new sqlite3.Database(dbPath);

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve(this);
    });
  });
}

async function seed() {
  await run("PRAGMA foreign_keys = ON");
  await run(schema);
  await run("DELETE FROM issues");
  await run("DELETE FROM books");
  await run("DELETE FROM members");

  const passwordHash = await bcrypt.hash("Pass@123", 10);

  const members = [
    [1, "Admin", "admin@lib.example", passwordHash, "librarian"],
    [2, "Aarav", "aarav@lib.example", passwordHash, "member"],
    [3, "Meera", "meera@lib.example", passwordHash, "member"],
    [4, "Rohan", "rohan@lib.example", passwordHash, "member"]
  ];

  for (const member of members) {
    await run(
      "INSERT INTO members(id,name,email,password_hash,role) VALUES(?,?,?,?,?)",
      member
    );
  }

  const books = [
    [1, "LIB-1001", "The Pragmatic Programmer", "Hunt & Thomas", 2, 2],
    [2, "LIB-1002", "Clean Code", "Robert C. Martin", 1, 1],
    [3, "LIB-1003", "Operating System Concepts", "Silberschatz", 3, 3],
    [4, "LIB-1004", "Database System Concepts", "Silberschatz", 1, 0],
    [5, "LIB-1005", "Computer Networks", "Tanenbaum", 2, 2]
  ];

  for (const book of books) {
    await run(
      "INSERT INTO books(id,code,title,author,total_copies,available_copies) VALUES(?,?,?,?,?,?)",
      book
    );
  }

  const issueDate = new Date();
  issueDate.setDate(issueDate.getDate() - 20);
  const dueDate = new Date(issueDate);
  dueDate.setDate(dueDate.getDate() + 14);

  await run(
    "INSERT INTO issues(id,member_id,book_id,issued_on,due_on,returned_on,fine) VALUES(?,?,?,?,?,?,?)",
    [
      1,
      4,
      4,
      issueDate.toISOString(),
      dueDate.toISOString(),
      null,
      0
    ]
  );

  console.log(`Seed complete: ${dbPath}`);
}

seed()
  .catch(err => {
    console.error(err);
    process.exitCode = 1;
  })
  .finally(() => db.close());
