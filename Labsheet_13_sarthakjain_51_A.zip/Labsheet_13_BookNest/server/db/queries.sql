-- Q1: Overdue list with member name, book title, days overdue and fine.
SELECT
  i.id AS issue_id,
  m.name AS member_name,
  b.title AS book_title,
  CAST(julianday('now') - julianday(i.due_on) AS INTEGER) AS days_overdue,
  (CAST(julianday('now') - julianday(i.due_on) AS INTEGER) * 2) AS fine
FROM issues i
JOIN members m ON m.id = i.member_id
JOIN books b ON b.id = i.book_id
WHERE i.returned_on IS NULL
  AND julianday('now') > julianday(i.due_on)
ORDER BY days_overdue DESC;

-- Q2: Top 3 most-issued books.
SELECT
  b.id,
  b.code,
  b.title,
  COUNT(i.id) AS issue_count
FROM books b
LEFT JOIN issues i ON i.book_id = b.id
GROUP BY b.id, b.code, b.title
ORDER BY issue_count DESC, b.id
LIMIT 3;
