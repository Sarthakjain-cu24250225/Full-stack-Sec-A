const fs = require("fs");
const os = require("os");
const path = require("path");
const request = require("supertest");
const bcrypt = require("bcrypt");
const { createApp } = require("../src/app");
const { calculateFine } = require("../src/utils");

process.env.JWT_SECRET = "test-secret";

let dbFile;
let app;
let adminToken;
let aaravToken;
let meeraToken;

async function seedTestDb() {
  const db = app.locals.db;
  const hash = await bcrypt.hash("Pass@123", 10);

  await db.exec(`
    CREATE TABLE members (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('librarian','member'))
    );
    CREATE TABLE books (
      id INTEGER PRIMARY KEY,
      code TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      author TEXT NOT NULL,
      total_copies INTEGER NOT NULL CHECK(total_copies >= 0),
      available_copies INTEGER NOT NULL CHECK(available_copies >= 0 AND available_copies <= total_copies)
    );
    CREATE TABLE issues (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      member_id INTEGER NOT NULL,
      book_id INTEGER NOT NULL,
      issued_on TEXT NOT NULL,
      due_on TEXT NOT NULL,
      returned_on TEXT,
      fine REAL NOT NULL DEFAULT 0 CHECK(fine >= 0)
    );
    CREATE INDEX idx_issues_member_returned ON issues(member_id, returned_on);
  `);

  for (const m of [
    [1, "Admin", "admin@lib.example", "librarian"],
    [2, "Aarav", "aarav@lib.example", "member"],
    [3, "Meera", "meera@lib.example", "member"],
    [4, "Rohan", "rohan@lib.example", "member"]
  ]) {
    await db.run(
      "INSERT INTO members VALUES(?,?,?,?,?)",
      [m[0], m[1], m[2], hash, m[3]]
    );
  }

  for (const b of [
    [1, "LIB-1001", "The Pragmatic Programmer", "Hunt & Thomas", 2, 2],
    [2, "LIB-1002", "Clean Code", "Robert C. Martin", 1, 1],
    [3, "LIB-1003", "Operating System Concepts", "Silberschatz", 3, 3],
    [4, "LIB-1004", "Database System Concepts", "Silberschatz", 1, 0],
    [5, "LIB-1005", "Computer Networks", "Tanenbaum", 2, 2]
  ]) {
    await db.run("INSERT INTO books VALUES(?,?,?,?,?,?)", b);
  }

  const issued = new Date();
  issued.setDate(issued.getDate() - 20);
  const due = new Date(issued);
  due.setDate(due.getDate() + 14);

  await db.run(
    "INSERT INTO issues(id,member_id,book_id,issued_on,due_on,returned_on,fine) VALUES(?,?,?,?,?,?,?)",
    [1, 4, 4, issued.toISOString(), due.toISOString(), null, 0]
  );
}

async function login(email, password = "Pass@123") {
  const response = await request(app)
    .post("/api/auth/login")
    .send({ email, password });
  return response.body.token;
}

beforeEach(async () => {
  dbFile = path.join(os.tmpdir(), `booknest-test-${process.pid}-${Date.now()}-${Math.random()}.db`);
  app = createApp(dbFile);
  await seedTestDb();
  adminToken = await login("admin@lib.example");
  aaravToken = await login("aarav@lib.example");
  meeraToken = await login("meera@lib.example");
});

afterEach(async () => {
  await app.locals.db.close();
  try { fs.unlinkSync(dbFile); } catch {}
});

test("wrong password gives 401", async () => {
  const res = await request(app)
    .post("/api/auth/login")
    .send({ email: "admin@lib.example", password: "wrong" });
  expect(res.status).toBe(401);
});

test("issuing last copy twice gives 409 NO_COPIES", async () => {
  const first = await request(app)
    .post("/api/issues")
    .set("Authorization", `Bearer ${adminToken}`)
    .send({ member_id: 2, book_id: 2 });

  expect(first.status).toBe(201);

  const second = await request(app)
    .post("/api/issues")
    .set("Authorization", `Bearer ${adminToken}`)
    .send({ member_id: 3, book_id: 2 });

  expect(second.status).toBe(409);
  expect(second.body.error.code).toBe("NO_COPIES");
});

test("fourth active issue gives LIMIT_REACHED", async () => {
  await request(app).post("/api/issues").set("Authorization", `Bearer ${adminToken}`).send({ member_id: 2, book_id: 1 });
  await request(app).post("/api/issues").set("Authorization", `Bearer ${adminToken}`).send({ member_id: 2, book_id: 3 });
  await request(app).post("/api/issues").set("Authorization", `Bearer ${adminToken}`).send({ member_id: 2, book_id: 5 });

  const fourth = await request(app)
    .post("/api/issues")
    .set("Authorization", `Bearer ${adminToken}`)
    .send({ member_id: 2, book_id: 2 });

  expect(fourth.status).toBe(409);
  expect(fourth.body.error.code).toBe("LIMIT_REACHED");
});

test("returning overdue seed issue gives fine 12", async () => {
  const res = await request(app)
    .post("/api/issues/1/return")
    .set("Authorization", `Bearer ${adminToken}`);

  expect(res.status).toBe(200);
  expect(res.body.fine).toBe(12);
});

test("calculateFine handles on-time, one day late and ten days late", () => {
  const due = new Date("2026-01-01T00:00:00.000Z");
  expect(calculateFine(due.toISOString(), "2026-01-01T23:00:00.000Z")).toBe(0);
  expect(calculateFine(due.toISOString(), "2026-01-02T00:00:01.000Z")).toBe(2);
  expect(calculateFine(due.toISOString(), "2026-01-11T00:00:00.000Z")).toBe(20);
});

test("books require authentication", async () => {
  const res = await request(app).get("/api/books");
  expect(res.status).toBe(401);
});

test("search treats SQL-looking text as plain text", async () => {
  const res = await request(app)
    .get("/api/books")
    .query({ search: "' OR '1'='1" })
    .set("Authorization", `Bearer ${aaravToken}`);

  expect(res.status).toBe(200);
  expect(res.body.total).toBe(0);
});

test("member cannot view librarian overdue endpoint", async () => {
  const res = await request(app)
    .get("/api/issues/overdue")
    .set("Authorization", `Bearer ${aaravToken}`);
  expect(res.status).toBe(403);
});

test("member sees only own issues", async () => {
  const res = await request(app)
    .get("/api/issues/mine")
    .set("Authorization", `Bearer ${aaravToken}`);
  expect(res.status).toBe(200);
  expect(res.body).toEqual([]);
});
