const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3000/api";

export async function api(path, options = {}) {
  const token = localStorage.getItem("booknest_token");
  const headers = {
    "Content-Type": "application/json",
    ...(options.headers || {})
  };

  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(`${API_URL}${path}`, { ...options, headers });

  if (response.status === 401) {
    localStorage.removeItem("booknest_token");
    localStorage.removeItem("booknest_user");
    window.location.href = "/login";
    throw new Error("Session expired. Please log in again.");
  }

  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { error: { message: text || "Request failed" } };
  }

  if (!response.ok) {
    throw new Error(data?.error?.message || "Request failed");
  }

  return data;
}
