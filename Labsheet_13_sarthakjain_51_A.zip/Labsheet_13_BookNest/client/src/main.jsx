import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  BrowserRouter,
  Link,
  Navigate,
  Route,
  Routes,
  useNavigate
} from "react-router-dom";
import { api } from "./api";
import "./styles.css";

function getUser() {
  try {
    return JSON.parse(localStorage.getItem("booknest_user") || "null");
  } catch {
    return null;
  }
}

function Protected({ children, librarianOnly = false }) {
  const user = getUser();
  if (!user) return <Navigate to="/login" replace />;
  if (librarianOnly && user.role !== "librarian") return <Navigate to="/books" replace />;
  return children;
}

function Layout({ children }) {
  const user = getUser();
  const navigate = useNavigate();

  function logout() {
    localStorage.removeItem("booknest_token");
    localStorage.removeItem("booknest_user");
    navigate("/login");
  }

  return (
    <>
      <header>
        <div className="nav">
          <Link to="/books">BookNest</Link>
          {user && <span>{user.name} ({user.role})</span>}
          <nav>
            {user?.role === "librarian" && <Link to="/librarian">Librarian</Link>}
            {user?.role === "member" && <Link to="/my-issues">My Issues</Link>}
            {user && <button onClick={logout}>Logout</button>}
          </nav>
        </div>
      </header>
      <main>{children}</main>
    </>
  );
}

function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("admin@lib.example");
  const [password, setPassword] = useState("Pass@123");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    if (!email || !password) {
      setError("Email and password are required.");
      return;
    }
    setLoading(true);
    try {
      const result = await api("/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password })
      });
      localStorage.setItem("booknest_token", result.token);
      localStorage.setItem("booknest_user", JSON.stringify(result.user));
      navigate("/books");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="card narrow">
      <h1>BookNest Login</h1>
      {error && <div className="error">{error}</div>}
      <form onSubmit={submit}>
        <label>Email<input value={email} onChange={e => setEmail(e.target.value)} /></label>
        <label>Password<input type="password" value={password} onChange={e => setPassword(e.target.value)} /></label>
        <button disabled={loading}>{loading ? "Logging in..." : "Login"}</button>
      </form>
      <p className="hint">Demo password for all seeded users: Pass@123</p>
    </section>
  );
}

function Books() {
  const [search, setSearch] = useState("");
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [meta, setMeta] = useState({ page: 1, limit: 5, total: 0, totalPages: 1 });
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const timer = setTimeout(() => {
      setQuery(search);
      setPage(1);
    }, 300);
    return () => clearTimeout(timer);
  }, [search]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    api(`/books?search=${encodeURIComponent(query)}&page=${page}&limit=5`)
      .then(result => {
        if (!cancelled) {
          setBooks(result.data);
          setMeta(result);
        }
      })
      .catch(err => !cancelled && setError(err.message))
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, [query, page]);

  return (
    <section>
      <h1>Book Catalogue</h1>
      <input
        value={search}
        onChange={e => setSearch(e.target.value)}
        placeholder="Search title or author..."
      />
      {error && <div className="error">{error}</div>}
      {loading && <p>Loading books...</p>}
      {!loading && !books.length && <div className="empty">No books found.</div>}
      <div className="grid">
        {books.map(book => (
          <article className="card" key={book.id}>
            <h2>{book.title}</h2>
            <p><strong>Code:</strong> {book.code}</p>
            <p><strong>Author:</strong> {book.author}</p>
            <p>Available: <strong>{book.available_copies}</strong> / {book.total_copies}</p>
          </article>
        ))}
      </div>
      <div className="pagination">
        <button disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Previous</button>
        <span>Page {meta.page} of {meta.totalPages} · {meta.total} books</span>
        <button disabled={page >= meta.totalPages} onClick={() => setPage(p => p + 1)}>Next</button>
      </div>
    </section>
  );
}

function MyIssues() {
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api("/issues/mine").then(setIssues).finally(() => setLoading(false));
  }, []);

  return (
    <section>
      <h1>My Issues</h1>
      {loading && <p>Loading...</p>}
      {!loading && !issues.length && <div className="empty">No issued books.</div>}
      <div className="table-wrap">
        <table>
          <thead><tr><th>Book</th><th>Issued</th><th>Due</th><th>Status</th><th>Fine</th></tr></thead>
          <tbody>
            {issues.map(i => (
              <tr key={i.id}>
                <td>{i.title}</td>
                <td>{new Date(i.issued_on).toLocaleDateString()}</td>
                <td>{new Date(i.due_on).toLocaleDateString()}</td>
                <td>{i.returned_on ? "Returned" : "Active"}</td>
                <td>₹{i.fine}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function Librarian() {
  const [members, setMembers] = useState([]);
  const [books, setBooks] = useState([]);
  const [overdue, setOverdue] = useState([]);
  const [memberId, setMemberId] = useState("");
  const [bookId, setBookId] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function load() {
    const [memberResult, bookResult, overdueResult] = await Promise.all([
      api("/books?limit=50"),
      api("/books?limit=50"),
      api("/issues/overdue")
    ]);
    setBooks(bookResult.data);
    setOverdue(overdueResult);
    // The member list endpoint is intentionally not exposed by the lab.
    // Use the known seeded member IDs for this lab UI.
    setMembers([
      { id: 2, name: "Aarav" },
      { id: 3, name: "Meera" },
      { id: 4, name: "Rohan" }
    ]);
  }

  useEffect(() => { load().catch(err => setError(err.message)); }, []);

  async function issue(e) {
    e.preventDefault();
    setMessage("");
    setError("");
    try {
      const result = await api("/issues", {
        method: "POST",
        body: JSON.stringify({ member_id: Number(memberId), book_id: Number(bookId) })
      });
      setMessage(`Issued successfully. Due ${new Date(result.due_on).toLocaleDateString()}.`);
      await load();
    } catch (err) {
      setError(err.message);
    }
  }

  async function returnBook(id) {
    try {
      const result = await api(`/issues/${id}/return`, { method: "POST" });
      setMessage(`Returned successfully. Fine charged: ₹${result.fine}`);
      await load();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <section>
      <h1>Librarian Dashboard</h1>
      {message && <div className="success">{message}</div>}
      {error && <div className="error">{error}</div>}

      <div className="card">
        <h2>Issue a Book</h2>
        <form onSubmit={issue} className="row-form">
          <select value={memberId} onChange={e => setMemberId(e.target.value)} required>
            <option value="">Choose member</option>
            {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
          </select>
          <select value={bookId} onChange={e => setBookId(e.target.value)} required>
            <option value="">Choose available book</option>
            {books.filter(b => b.available_copies > 0).map(b => (
              <option key={b.id} value={b.id}>{b.title} ({b.available_copies})</option>
            ))}
          </select>
          <button>Issue</button>
        </form>
      </div>

      <div className="card">
        <h2>Overdue Issues</h2>
        {!overdue.length && <div className="empty">No overdue issues.</div>}
        <div className="table-wrap">
          <table>
            <thead><tr><th>Member</th><th>Book</th><th>Days</th><th>Fine</th><th>Action</th></tr></thead>
            <tbody>
              {overdue.map(i => (
                <tr key={i.id}>
                  <td>{i.member_name}</td>
                  <td>{i.book_title}</td>
                  <td>{i.days_overdue}</td>
                  <td>₹{i.fine}</td>
                  <td><button onClick={() => returnBook(i.id)}>Return</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Navigate to="/books" replace />} />
        <Route path="/books" element={<Protected><Layout><Books /></Layout></Protected>} />
        <Route path="/my-issues" element={<Protected><Layout><MyIssues /></Layout></Protected>} />
        <Route path="/librarian" element={<Protected librarianOnly><Layout><Librarian /></Layout></Protected>} />
      </Routes>
    </BrowserRouter>
  );
}

createRoot(document.getElementById("root")).render(<App />);
