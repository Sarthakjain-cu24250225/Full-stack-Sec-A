# Labsheet 13 Submission Checklist

- [x] /server and /client folders
- [x] README with architecture, JWT flow and ER diagram
- [x] API table
- [x] SQLite schema
- [x] Required constraints and index
- [x] Seed script with bcrypt hashes
- [x] queries.sql
- [x] JWT authentication and role middleware
- [x] Parameterised book search
- [x] Pagination capped at 50
- [x] Transactional issue and return logic
- [x] NO_COPIES, LIMIT_REACHED and ALREADY_RETURNED errors
- [x] React Router protected pages
- [x] 300 ms debounced book search
- [x] api.js wrapper
- [x] Loading, error and empty states
- [x] Mobile layout at 360px
- [x] Jest + Supertest tests
- [x] .env.example and .gitignore
- [x] Node 20 Alpine Dockerfile
- [x] Non-root Docker user
- [x] GitHub Actions CI
- [x] Six suggested meaningful commits documented in README

Before submission:
1. Run `npm install` in both server and client.
2. Run `npm run seed` in server.
3. Run `npm test`.
4. Run the API and frontend.
5. Test the examiner scenarios.
6. Make at least 6 meaningful commits.
7. Do not upload node_modules, .env, or database files.
