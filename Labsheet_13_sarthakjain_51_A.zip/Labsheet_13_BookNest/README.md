# BookNest Library Tracker — Labsheet 13

Secure full-stack library tracker built for the Full Stack Lab.

## Stack

- Frontend: React + Vite + React Router
- Backend: Node.js + Express
- Database: SQLite
- Authentication: bcrypt + JWT
- Testing: Jest + Supertest
- Security/middleware: helmet, cors, request logging
- Container: Docker, Node 20 Alpine
- CI: GitHub Actions

## Architecture

```mermaid
flowchart LR
    B[Browser] --> R[React + Vite]
    R --> A[Express REST API]
    A --> M[Auth Middleware]
    A --> C[Controllers]
    C --> D[(SQLite Database)]
```

## JWT flow

```mermaid
sequenceDiagram
    participant U as User
    participant F as React
    participant S as REST API
    participant DB as SQLite

    U->>F: Login email/password
    F->>S: POST /api/auth/login
    S->>DB: Find member
    S->>S: bcrypt.compare()
    S-->>F: JWT + user
    F->>F: Store token in localStorage
    F->>S: API request + Bearer JWT
    S->>S: Verify JWT
    S->>DB: Parameterised query
    DB-->>S: Result
    S-->>F: JSON response
```

### Token storage trade-off

This demo stores the JWT in `localStorage` because it is simple for a lab SPA and survives refreshes. The trade-off is that a successful XSS attack could read the token. A production system would normally prefer a secure, HttpOnly, SameSite cookie with appropriate CSRF protection.

## ER diagram

```mermaid
erDiagram
    MEMBERS ||--o{ ISSUES : has
    BOOKS ||--o{ ISSUES : appears_in

    MEMBERS {
        INTEGER id PK
        TEXT name
        TEXT email UK
        TEXT password_hash
        TEXT role
    }

    BOOKS {
        INTEGER id PK
        TEXT code UK
        TEXT title
        TEXT author
        INTEGER total_copies
        INTEGER available_copies
    }

    ISSUES {
        INTEGER id PK
        INTEGER member_id FK
        INTEGER book_id FK
        TEXT issued_on
        TEXT due_on
        TEXT returned_on
        REAL fine
    }
```

## API table

| Method | Endpoint | Access | Success |
|---|---|---|---|
| POST | `/api/auth/login` | Public | `200 {token,user}` |
| GET | `/api/books?search=&page=&limit=` | Logged in | `200 {data,page,limit,total,totalPages}` |
| POST | `/api/books` | Librarian | `201` |
| POST | `/api/issues` | Librarian | `201` |
| POST | `/api/issues/:id/return` | Librarian | `200 {fine}` |
| GET | `/api/issues/overdue` | Librarian | `200 list` |
| GET | `/api/issues/mine` | Member | `200 list` |

## Seed users

All seed users use password `Pass@123`. Only the bcrypt hash is stored.

| ID | Name | Email | Role |
|---|---|---|---|
| 1 | Admin | admin@lib.example | librarian |
| 2 | Aarav | aarav@lib.example | member |
| 3 | Meera | meera@lib.example | member |
| 4 | Rohan | rohan@lib.example | member |

Seed books are the five books specified in the lab sheet. The seed issue belongs to Rohan and is 20 days old, giving 6 days overdue and a ₹12 fine.

## Database index

`issues(member_id, returned_on)` speeds up queries that find a member's active issues and count active issues for the 3-book limit.

## Backend setup

From the repository root:

```bash
cd server
npm install
npm run seed
npm start
```

API runs on `http://localhost:3000`.

## Frontend setup

Open another terminal:

```bash
cd client
npm install
npm run dev
```

Vite normally runs on `http://localhost:5173`.

## Tests

```bash
cd server
npm test
```

The CI workflow uses `npm install` so the project can be cloned and installed directly without committing generated lockfiles. The application dependencies are declared in each package.json.

The test suite uses a separate SQLite test database and resets it before each test.

## Docker

From the repository root:

```bash
docker build -t booknest-api ./server
docker run --rm -p 3000:3000 booknest-api
```

The API container uses Node 20 Alpine and runs as a non-root user.

## Three quick commands

Install:

```bash
cd server && npm install
```

Seed:

```bash
npm run seed
```

Run:

```bash
npm start
```

## Security notes

- Passwords are bcrypt hashes.
- JWT expires after one hour.
- JWT middleware is reusable.
- Librarian routes use role middleware.
- SQL uses parameterised statements.
- Issue creation uses a transaction and an atomic `available_copies > 0` update.
- Return is transactional.
- Central error handling avoids stack traces in API responses.
- `.env` and `node_modules` are ignored by Git.

## Suggested meaningful commits

The lab asks for at least six meaningful commits. Example sequence:

```bash
git add README.md .gitignore
git commit -m "Add BookNest project documentation"

git add server/db
git commit -m "Add SQLite schema and seed data"

git add server/src/middleware server/src/routes server/src/controllers
git commit -m "Implement authentication and library API"

git add client
git commit -m "Build React BookNest interface"

git add server/test
git commit -m "Add API and business rule tests"

git add server/Dockerfile .github/workflows/ci.yml
git commit -m "Add Docker and CI workflow"
```

Do not commit `.env`, database files, or `node_modules`.
