const test=require("node:test"),assert=require("node:assert/strict");
const{app,users,tasks,failedLogins}=require("./server");
test("Express app is exported",()=>assert.equal(typeof app,"function"));
test("in-memory stores exist",()=>{assert.ok(users instanceof Map);assert.ok(tasks instanceof Map);assert.ok(failedLogins instanceof Map);});
