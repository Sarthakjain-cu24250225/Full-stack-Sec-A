# Labsheet 12 – Full Stack Coding Assessment

Complete solutions for all four BTCS303T assessment problems.

## Structure
- `problem1-secure-task-api/` — Node.js + Express + bcrypt + JWT
- `problem2-sql-analytics/answers.sql` — SQL analytics and concurrency
- `problem3-react-product-search/` — React + Vite search, pagination and cart
- `.github/workflows/ci.yml` — GitHub Actions CI/CD
- `problem4-git-recovery.md` — Git recovery solution

## Problem 1
```bash
cd problem1-secure-task-api
npm install
npm start
```
Server runs on `http://localhost:3000`. Tests: `npm test`.
Copy `.env.example` to `.env` and set `JWT_SECRET`.

## Problem 3
```bash
cd problem3-react-product-search
npm install
npm run dev
```

## GitHub
```bash
git add .
git commit -m "Add Labsheet 12 solutions"
git push
```
Never commit `.env` or `node_modules`.
