# Problem 4(b) — Git Recovery

```bash
git reflog --all
git branch recovery <LOST_COMMIT_SHA>
git switch recovery
git log --oneline recovery
git push -u origin recovery
```

Review the recovery branch and merge it through a Pull Request. If a teammate still has the commits, `git log --all --oneline` can locate their local history.

**Prevention:** protect/ruleset the `main` branch so force pushes are blocked and Pull Requests/status checks are required.
