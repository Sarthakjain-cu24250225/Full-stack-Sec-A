-- Labsheet 12 Problem 2
-- (a) Top 3 products by revenue per category; ties included.
WITH product_revenue AS (
 SELECT p.id,p.name,p.category,p.price*SUM(oi.qty) AS revenue
 FROM products p JOIN order_items oi ON oi.product_id=p.id
 JOIN orders o ON o.id=oi.order_id
 GROUP BY p.id,p.name,p.category,p.price
), ranked AS (
 SELECT *,DENSE_RANK() OVER(PARTITION BY category ORDER BY revenue DESC) AS rnk
 FROM product_revenue
)
SELECT id,name,category,revenue FROM ranked WHERE rnk<=3 ORDER BY category,rnk,name;

-- (b) Customers with at least one order in Jan, Feb and Mar 2025.
SELECT c.id,c.name,c.city
FROM customers c JOIN orders o ON o.customer_id=c.id
WHERE o.order_date>='2025-01-01' AND o.order_date<'2025-04-01'
GROUP BY c.id,c.name,c.city
HAVING COUNT(DISTINCT EXTRACT(MONTH FROM o.order_date))=3;

-- (c) Atomic transaction preventing overselling.
BEGIN;
UPDATE products SET stock=stock-:qty WHERE id=:product_id AND stock>=:qty;
-- If affected rows = 0: ROLLBACK and report insufficient stock/product missing.
INSERT INTO orders(customer_id,order_date) VALUES(:customer_id,CURRENT_TIMESTAMP) RETURNING id;
INSERT INTO order_items(order_id,product_id,qty) VALUES(:order_id,:product_id,:qty);
COMMIT;

-- A separate SELECT then UPDATE is unsafe because two requests can read the same
-- stock before either writes. The conditional UPDATE performs check and decrement atomically.
